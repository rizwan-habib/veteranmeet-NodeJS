const doctor = [
    {
     id: 1,
     rating:3,
     comment:"Hello jani loarai aiahr aab adjha adabdd daa u",
     name:"Numan",
   bookedSlots:[
    {
      to:'Feb 8 2022 15',
      from:'Feb 8 2022 14'
    },
    {
      to:'Feb 9 2022 14',
      from:'Feb 8 2022 11'
    },
    {
      to:'Feb 2 2022 14',
      from:'Feb 8 2022 11'
    },
    {
      to:'Feb 4 2022 14',
      from:'Feb 8 2022 11'
    },
  ]

  },
  {
     id: 2,
     rating:4,
     comment:"Hello jani adad adda ad ad ada add  a wa wa ad da ae a  dad ",
     name:"Uzair",
     bookedSlots:[
    {
      to:'Feb 18 2022 14',
      from:'Feb 18 2022 11'
    },
    {
      to:'Feb 19 2022 14',
      from:'Feb 18 2022 11'
    },
    {
      to:'Feb 22 2022 14',
      from:'Feb 18 2022 11'
    },
    {
      to:'Feb 24 2022 14',
      from:'Feb 18 2022 11'
    },
  ]
  },
  {
     id: 3,
     rating:5,
     comment:"Hello jani a ddadadadaadf fffafa f a faf afafaaa ddadfad affaafaf dadaa ",
     name:"Muzammil",
     bookedSlots:[
    {
      to:'Feb 10 2022 14',
      from:'Feb 11 2022 11'
    },
    {
      to:'Feb 12 2022 14',
      from:'Feb 14 2022 11'
    },
    {
      to:'Feb 14 2022 14',
      from:'Feb 16 2022 11'
    },
    {
      to:'Feb 18 2022 14',
      from:'Feb 19 2022 11'
    },
  ]
  },
  {
     id: 3,
     rating:5,
     comment:"Hello jani a ddadadadaadf fffafa f a faf afafaaa ddadfad affaafaf dadaa ",
     name:"Muzammil",
     bookedSlots:[
    {
      to:'Feb 10 2022 14',
      from:'Feb 11 2022 11'
    },
    {
      to:'Feb 12 2022 14',
      from:'Feb 14 2022 11'
    },
    {
      to:'Feb 14 2022 14',
      from:'Feb 16 2022 11'
    },
    {
      to:'Feb 18 2022 14',
      from:'Feb 19 2022 11'
    },
  ]
  },
  {
     id: 3,
     rating:5,
     comment:"Hello jani a ddadadadaadf fffafa f a faf afafaaa ddadfad affaafaf dadaa ",
     name:"Muzammil",
     bookedSlots:[
    {
      to:'Feb 10 2022 14',
      from:'Feb 11 2022 11'
    },
    {
      to:'Feb 12 2022 14',
      from:'Feb 14 2022 11'
    },
    {
      to:'Feb 14 2022 14',
      from:'Feb 16 2022 11'
    },
    {
      to:'Feb 18 2022 14',
      from:'Feb 19 2022 11'
    },
  ]
  },
  {
     id: 3,
     rating:5,
     comment:"Hello jani a ddadadadaadf fffafa f a faf afafaaa ddadfad affaafaf dadaa ",
     name:"Muzammil",
     bookedSlots:[
    {
      to:'Feb 10 2022 14',
      from:'Feb 11 2022 11'
    },
    {
      to:'Feb 12 2022 14',
      from:'Feb 14 2022 11'
    },
    {
      to:'Feb 14 2022 14',
      from:'Feb 16 2022 11'
    },
    {
      to:'Feb 18 2022 14',
      from:'Feb 19 2022 11'
    },
  ]
  },
  {
     id: 3,
     rating:5,
     comment:"Hello jani a ddadadadaadf fffafa f a faf afafaaa ddadfad affaafaf dadaa ",
     name:"Muzammil",
     bookedSlots:[
    {
      to:'Feb 10 2022 14',
      from:'Feb 11 2022 11'
    },
    {
      to:'Feb 12 2022 14',
      from:'Feb 14 2022 11'
    },
    {
      to:'Feb 14 2022 14',
      from:'Feb 16 2022 11'
    },
    {
      to:'Feb 18 2022 14',
      from:'Feb 19 2022 11'
    },
  ]
  },
  {
     id: 3,
     rating:5,
     comment:"Hello jani a ddadadadaadf fffafa f a faf afafaaa ddadfad affaafaf dadaa ",
     name:"Muzammil",
     bookedSlots:[
    {
      to:'Feb 10 2022 14',
      from:'Feb 11 2022 11'
    },
    {
      to:'Feb 12 2022 14',
      from:'Feb 14 2022 11'
    },
    {
      to:'Feb 14 2022 14',
      from:'Feb 16 2022 11'
    },
    {
      to:'Feb 18 2022 14',
      from:'Feb 19 2022 11'
    },
  ]
  },
  {
     id: 3,
     rating:5,
     comment:"Hello jani a ddadadadaadf fffafa f a faf afafaaa ddadfad affaafaf dadaa ",
     name:"Muzammil",
     bookedSlots:[
    {
      to:'Feb 10 2022 14',
      from:'Feb 11 2022 11'
    },
    {
      to:'Feb 12 2022 14',
      from:'Feb 14 2022 11'
    },
    {
      to:'Feb 14 2022 14',
      from:'Feb 16 2022 11'
    },
    {
      to:'Feb 18 2022 14',
      from:'Feb 19 2022 11'
    },
  ]
  },
];
export default doctor;
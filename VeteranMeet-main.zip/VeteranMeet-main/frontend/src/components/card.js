 import DocImage from "../img/org.png"
 const card = [
  {
     id: 1,
     image : `${DocImage}`,
     name : "Jinnah Hospital",
     Doc : "Numan Anees",
     Specialization : "Heart",
     phone:"03010145649"

  },
  {
     id: 2,
     image : `${DocImage}`,
     name : "Jinnah",
     Doc : "Numan",
     Specialization : "Brain",
     phone:"03010145649"

  },
  {
     id: 3,
     image : `${DocImage}`,
     name : "Hua",
     Doc : "Uzair",
     Specialization : "Surgery",
     phone:"03010145649"

  },
  {
     id: 3,
     image : `${DocImage}`,
     name : "Hua",
     Doc : "Uzair",
     Specialization : "Kidney",
     phone:"03010145649"

  },
  {
     id: 3,
     image : `${DocImage}`,
     name : "Hua",
     Doc : "Uzair",
     Specialization : "kidney",
     phone:"03010145649"

  },
  
];
export default card;
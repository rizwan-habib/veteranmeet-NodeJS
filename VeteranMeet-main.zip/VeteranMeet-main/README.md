# VeteranMeet
VeteranMeet is web based solution to connect with veterans and engage them into community
services based on their interests. A veteran (from Latin vetus, meaning "old") is a person who has
had long service or experience in a particular occupation or field.This application will help
veterans of any profession to connect with other veterans and socialize through our platform and
can participate into any community services such public talks, motivational speeches into
educational institutions and organization, plantation drive and picnic etc. Additionally, they seecan
take initiate a new community service and can involve other veterans into it.
Coded this full stack web app in 12 hours for Nascon 2022 web development competition.
Major module in this project were 
- Authorization using JWT
- Veterans can view profile of other veterans and organizations.
- Veterans can follow veterans and organizations.
- Veterans can search other veterans and organizations.
- Veterans can post on their profiles.
- Veterans can create, view and join events.
- Veterans can send event invitations to their followers.
- Veterans can accept/reject invitations.
- Organizations can create events and can send invitations to the veterans with matching hobbies.

## REMINDER: 
This project was built by me and my team within 12 hours for the web development hackathon so there can be undectected bugs.
